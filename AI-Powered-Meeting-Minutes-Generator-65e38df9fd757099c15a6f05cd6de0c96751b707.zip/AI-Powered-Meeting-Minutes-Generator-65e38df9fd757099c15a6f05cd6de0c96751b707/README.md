# AI-Powered-Meeting-Minutes-Generator
AI-powered meeting minutes generator that can transcribe, summarize, and organize discussions automatically.
